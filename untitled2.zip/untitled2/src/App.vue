<script setup>
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
import HomeView from './product/presentation/views/HomeView.vue'
import FormView from './product/presentation/views/FormView.vue'

const { locale } = useI18n()
const currentView = ref('home')

const toggleLang = (lang) => {
  locale.value = lang
}
</script>

<template>
  <div class="app-container">
    <nav class="navbar">
      <div class="nav-brand">
        <span class="logo-dot"></span>
        Tend <span class="light-text">Agro</span>
      </div>

      <div class="nav-menu">
        <button :class="{ active: currentView === 'home' }" @click="currentView = 'home'">
          {{ $t('nav.catalog') }}
        </button>
        <button :class="{ active: currentView === 'form' }" @click="currentView = 'form'">
          {{ $t('nav.newProduct') }}
        </button>
      </div>

      <div class="lang-switcher">
        <button :class="{ active: locale === 'es' }" @click="toggleLang('es')">ES</button>
        <span class="divider">|</span>
        <button :class="{ active: locale === 'en' }" @click="toggleLang('en')">EN</button>
      </div>
    </nav>

    <main class="main-layout">
      <Transition name="fade" mode="out-in">
        <HomeView v-if="currentView === 'home'" />
        <FormView v-else />
      </Transition>
    </main>

    <footer class="main-footer">
      <div class="footer-content">
        <div class="footer-brand">
          <span class="logo-dot small"></span>
          <span>Tend Agro Studio</span>
        </div>
        <p class="footer-copy">
          &copy; 2026 Tend Agro. {{ locale === 'en' ? 'All rights reserved.' : 'Todos los derechos reservados.' }}
        </p>
      </div>
    </footer>
  </div>
</template>

<style>
:root {
  --primary: #16a34a;
  --primary-hover: #15803d;
  --background: #f8fafc;
  --surface: #ffffff;
  --text-main: #0f172a;
  --text-muted: #64748b;
  --border: #e2e8f0;
  --radius: 16px;
  --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
}

* { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', system-ui, sans-serif; }

body { background-color: var(--background); color: var(--text-main); }

/* Distribución para empujar el footer siempre al fondo */
.app-container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.navbar { display: flex; justify-content: space-between; align-items: center; padding: 1.25rem 4rem; background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(12px); border-bottom: 1px solid var(--border); position: sticky; top: 0; z-index: 50; }
.nav-brand { font-weight: 800; font-size: 1.4rem; display: flex; align-items: center; gap: 8px; letter-spacing: -0.5px; }
.logo-dot { width: 10px; height: 10px; background: #16a34a; border-radius: 50%; }
.logo-dot.small { width: 7px; height: 7px; }
.light-text { color: var(--text-muted); font-weight: 400; }
.nav-menu { display: flex; background: #f1f5f9; padding: 4px; border-radius: 100px; }
.nav-menu button { background: none; border: none; padding: 0.6rem 1.5rem; font-size: 0.9rem; font-weight: 600; cursor: pointer; color: var(--text-muted); border-radius: 100px; transition: all 0.25s; }
.nav-menu button.active { background: var(--surface); color: #16a34a; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
.lang-switcher { display: flex; align-items: center; gap: 6px; font-weight: 600; font-size: 0.85rem; }
.lang-switcher button { background: none; border: none; cursor: pointer; color: var(--text-muted); }
.lang-switcher button.active { color: #16a34a; }
.divider { color: var(--border); }

/* Se añade flex-grow para que el contenido ocupe el espacio disponible */
.main-layout { padding: 3rem 4rem; max-width: 1400px; margin: 0 auto; flex-grow: 1; width: 100%; }

.fade-enter-active, .fade-leave-active { transition: opacity 0.2s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

/* ESTILOS PREMIUM DEL FOOTER */
.main-footer {
  background: #ffffff;
  border-top: 1px solid var(--border);
  padding: 1.5rem 4rem;
  margin-top: auto; /* Empuja el footer hacia el límite inferior */
}
.footer-content {
  max-width: 1320px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.footer-brand {
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: 700;
  font-size: 0.9rem;
  color: var(--text-main);
}
.footer-copy {
  font-size: 0.85rem;
  color: var(--text-muted);
  font-weight: 500;
}

/* Responsivo simple para pantallas pequeñas */
@media (max-width: 640px) {
  .navbar, .main-layout, .main-footer { padding: 1rem 1.5rem; }
  .footer-content { flex-direction: column; gap: 0.5rem; text-align: center; }
}
</style>