export class Product {
    constructor({ id, name, location, hectares, monitoringStartDate }) {
        this.id = id;
        this.name = this.validateName(name);
        this.location = location;
        this.hectares = Number(hectares);
        this.monitoringStartDate = monitoringStartDate;
        this.imageUrl = `https://picsum.photos/id/${Number(id) + 45}/300/200`;
    }

    validateName(name) {
        if (!name || name.trim() === '') {
            throw new Error('El nombre de la parcela es obligatorio.');
        }
        return name.toUpperCase();
    }

    get fullDetails() {
        return `${this.location} • ${this.hectares} Hectáreas`;
    }
}