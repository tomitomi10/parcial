export class ProductRepository {
    async getAll() {
        throw new Error("El método 'getAll()' debe ser implementado por la infraestructura.");
    }
    async save(productData) {
        throw new Error("El método 'save()' debe ser implementado por la infraestructura.");
    }
    async update(id, updatedData) {
        throw new Error("El método 'update()' debe ser implementado por la infraestructura.");
    }
}