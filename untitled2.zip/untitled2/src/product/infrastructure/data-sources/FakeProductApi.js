import { ProductRepository } from '../../domain/repository/ProductRepository';
import { Product } from '../../domain/models/Product';
import localDatabase from '../../../../server/db.json';

export class FakeProductApi extends ProductRepository {
    constructor() {
        super();
        this.db = localDatabase;
    }

    async getAll() {
        try {
            const rawData = this.db.plots || [];
            return rawData.map(item => new Product({
                id: item.id,
                name: item.name,
                location: item.location,
                hectares: item.hectares,
                monitoringStartDate: item.monitoringStartDate
            }));
        } catch (error) {
            console.error('[Infrastructure Local GET Error]:', error);
            return [];
        }
    }

    async save(productData) {
        try {
            const newInspection = {
                id: (this.db.inspections.length + 1),
                plotId: Number(productData.plotId),
                observations: productData.observations,
                recommendedActions: productData.recommendedActions,
                cropStatus: productData.cropStatus,
                inspectionDate: productData.inspectionDate
            };
            this.db.inspections.push(newInspection);
            return newInspection;
        } catch (error) {
            console.error('[Infrastructure Local POST Error]:', error);
            throw error;
        }
    }

    async update(id, updatedData) {
        try {
            const index = this.db.plots.findIndex(plot => plot.id === Number(id));
            if (index === -1) throw new Error('La parcela solicitada no existe.');

            this.db.plots[index].name = updatedData.name;
            this.db.plots[index].location = updatedData.location;
            this.db.plots[index].hectares = Number(updatedData.hectares);

            return new Product(this.db.plots[index]);
        } catch (error) {
            console.error('[Infrastructure Local UPDATE Error]:', error);
            throw error;
        }
    }
}