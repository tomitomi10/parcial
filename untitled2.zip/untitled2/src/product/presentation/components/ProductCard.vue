<script setup>
defineProps({
  item: { type: Object, required: true }
});
</script>

<template>
  <div class="modern-card">
    <div class="image-wrapper">
      <img :src="item.imageUrl" alt="Plot Thumbnail" loading="lazy" />
      <span class="id-badge">ID: {{ item.id }}</span>
    </div>
    <div class="card-body">
      <h3>{{ item.name }}</h3>
      <div class="status-pill">{{ item.fullDetails }}</div>
      <p class="date-info">
        <strong>{{ $t('catalog.startDate') }}</strong> {{ item.monitoringStartDate }}
      </p>
    </div>
    <div class="card-footer">
      <button class="btn-action">{{ $t('catalog.btnDetails') }}</button>
    </div>
  </div>
</template>

<style scoped>
.modern-card {
  background: var(--surface);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  border: 1px solid rgba(226, 232, 240, 0.7);
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.3s ease;
}
.modern-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.08);
}
.image-wrapper { position: relative; height: 175px; overflow: hidden; }
.image-wrapper img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s; }
.modern-card:hover .image-wrapper img { transform: scale(1.04); }
.id-badge {
  position: absolute; top: 12px; left: 12px;
  background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(4px);
  color: white; padding: 3px 9px; font-size: 0.75rem; font-weight: 700; border-radius: 100px;
}
.card-body { padding: 1.5rem; flex-grow: 1; display: flex; flex-direction: column; gap: 0.6rem; }
.card-body h3 { font-size: 1.2rem; font-weight: 800; color: var(--text-main); letter-spacing: -0.3px; }
.status-pill {
  background: #f0fdf4; color: #166534; font-size: 0.8rem;
  font-weight: 600; padding: 4px 10px; border-radius: 6px; width: fit-content;
}
.date-info { color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem; }
.card-footer { padding: 1.2rem 1.5rem; background: #fafafa; border-top: 1px solid var(--border); }
.btn-action {
  width: 100%; padding: 0.75rem; background: var(--background);
  color: var(--text-main); border: 1px solid var(--border); border-radius: 10px;
  font-weight: 600; font-size: 0.85rem; cursor: pointer; transition: all 0.2s;
}
.btn-action:hover { background: #16a34a; color: white; border-color: #16a34a; }
</style>