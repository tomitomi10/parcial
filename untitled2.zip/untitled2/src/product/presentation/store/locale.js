import { createI18n } from 'vue-i18n';

const messages = {
    es: {
        nav: { catalog: 'Ver Parcelas', newProduct: 'Nueva Inspección' },
        catalog: {
            title: 'Monitoreo Técnico - Tend Agro',
            subtitle: 'Panel de control para la sostenibilidad y gestión de cultivos urbanos.',
            loading: 'Cargando parcelas del sistema...',
            btnDetails: 'Detalles del Campo',
            startDate: 'Monitoreo desde:',
            btnEditTrigger: 'Editar Datos'
        },
        form: {
            title: 'Registro de Inspección Manual',
            subtitle: 'Reporta observaciones críticas directamente desde el terreno.',
            labelPlot: 'Seleccionar Parcela Urbana',
            labelStatus: 'Estado Sanitario del Cultivo',
            labelObs: 'Observaciones de Campo',
            labelActions: 'Acciones Correctivas Recomendadas',
            phObs: 'Ej. Hojas inferiores presentan decoloración leve por humedad...',
            phActions: 'Ej. Regular el temporizador de irrigación y podar maleza...',
            btnSave: 'Enviar Reporte Técnico',
            btnSaving: 'Guardando en memoria...'
        },
        modal: {
            title: 'Modificar Parcela',
            labelName: 'Nombre de la Parcela',
            labelLocation: 'Ubicación / Sector',
            labelHectares: 'Hectáreas de Cultivo',
            btnCancel: 'Cancelar',
            btnSave: 'Guardar Cambios'
        }
    },
    en: {
        nav: { catalog: 'View Plots', newProduct: 'New Inspection' },
        catalog: {
            title: 'Technical Monitoring - Tend Agro',
            subtitle: 'Control dashboard for sustainability and urban crop management.',
            loading: 'Loading plots from system...',
            btnDetails: 'Field Details',
            startDate: 'Monitoring since:',
            btnEditTrigger: 'Edit Data'
        },
        form: {
            title: 'Manual Inspection Log',
            subtitle: 'Report critical observations directly from the terrain.',
            labelPlot: 'Select Urban Plot',
            labelStatus: 'Crop Health Status',
            labelObs: 'Field Observations',
            labelActions: 'Recommended Corrective Actions',
            phObs: 'e.g., Lower leaves show slight discoloration due to moisture...',
            phActions: 'e.g., Adjust irrigation timer and clear weeds...',
            btnSave: 'Submit Technical Report',
            btnSaving: 'Saving to memory...'
        },
        modal: {
            title: 'Modify Urban Plot',
            labelName: 'Plot Name',
            labelLocation: 'Location / Sector',
            labelHectares: 'Crop Hectares',
            btnCancel: 'Cancel',
            btnSave: 'Save Changes'
        }
    }
};

const i18n = createI18n({
    legacy: false,
    locale: 'es',
    fallbackLocale: 'en',
    messages
});

export default i18n;