<script setup>
import { reactive, ref, onMounted } from 'vue';
import { useI18n } from 'vue-i18n';
import { FakeProductApi } from '../../infrastructure/data-sources/FakeProductApi';

const productRepository = new FakeProductApi();
const { t } = useI18n();

const itemsList = ref([]);
const isSubmitting = ref(false);
const feedback = ref({ msg: '', type: '' });

const form = reactive({
  plotId: '',
  observations: '',
  recommendedActions: '',
  cropStatus: 'Saludable'
});

onMounted(async () => {
  itemsList.value = await productRepository.getAll();
});

const onSubmit = async () => {
  if (!form.plotId) {
    feedback.value = { msg: 'Por favor, elija una parcela válida.', type: 'error' };
    return;
  }

  isSubmitting.value = true;
  feedback.value = { msg: '', type: '' };

  try {
    await productRepository.save({
      plotId: form.plotId,
      observations: form.observations,
      recommendedActions: form.recommendedActions,
      cropStatus: form.cropStatus,
      inspectionDate: new Date().toISOString().split('T')[0]
    });

    feedback.value = { msg: '¡Éxito! Reporte de inspección guardado en el servidor db.json.', type: 'success' };

    form.plotId = '';
    form.observations = '';
    form.recommendedActions = '';
    form.cropStatus = 'Saludable';
  } catch (error) {
    feedback.value = { msg: error.message, type: 'error' };
  } finally {
    isSubmitting.value = false;
  }
};
</script>

<template>
  <div class="form-container">
    <div class="card-holder">
      <h2>{{ t('form.title') }}</h2>
      <p class="subtitle">{{ t('form.subtitle') }}</p>

      <form @submit.prevent="onSubmit" class="custom-form">
        <div class="form-group">
          <label for="plotId">{{ t('form.labelPlot') }}</label>
          <select id="plotId" v-model="form.plotId" :disabled="isSubmitting">
            <option value="" disabled selected>-- Elige una opción --</option>
            <option v-for="item in itemsList" :key="item.id" :value="item.id">
              {{ item.name }} ({{ item.location }})
            </option>
          </select>
        </div>

        <div class="form-group">
          <label for="status">{{ t('form.labelStatus') }}</label>
          <select id="status" v-model="form.cropStatus" :disabled="isSubmitting">
            <option value="Saludable">Saludable ✅</option>
            <option value="En Riesgo">En Riesgo ⚠️</option>
            <option value="Crítico">Crítico 🚨</option>
          </select>
        </div>

        <div class="form-group">
          <label for="obs">{{ t('form.labelObs') }}</label>
          <textarea id="obs" v-model="form.observations" rows="4" :placeholder="t('form.phObs')" :disabled="isSubmitting" required></textarea>
        </div>

        <div class="form-group">
          <label for="actions">{{ t('form.labelActions') }}</label>
          <textarea id="actions" v-model="form.recommendedActions" rows="3" :placeholder="t('form.phActions')" :disabled="isSubmitting" required></textarea>
        </div>

        <div v-if="feedback.msg" :class="['feedback-alert', feedback.type]">
          {{ feedback.msg }}
        </div>

        <button type="submit" class="btn-send" :disabled="isSubmitting">
          {{ isSubmitting ? t('form.btnSaving') : t('form.btnSave') }}
        </button>
      </form>
    </div>
  </div>
</template>

<style scoped>
.form-container { display: flex; justify-content: center; padding: 1rem 0; }
.card-holder { background: var(--surface); max-width: 580px; width: 100%; padding: 3rem; border-radius: var(--radius); box-shadow: var(--shadow); border: 1px solid rgba(226, 232, 240, 0.7); }
.card-holder h2 { font-size: 1.75rem; font-weight: 800; margin-bottom: 0.4rem; letter-spacing: -0.4px; }
.subtitle { color: var(--text-muted); font-size: 0.95rem; margin-bottom: 2.5rem; line-height: 1.5; }
.custom-form { display: flex; flex-direction: column; gap: 1.4rem; }
.form-group { display: flex; flex-direction: column; gap: 0.5rem; }
label { font-size: 0.8rem; font-weight: 700; color: var(--text-main); text-transform: uppercase; letter-spacing: 0.5px; }
select, textarea { padding: 0.85rem 1rem; border: 1px solid var(--border); background: #f8fafc; border-radius: 10px; font-size: 0.95rem; color: var(--text-main); outline: none; transition: all 0.2s; }
select:focus, textarea:focus { background: var(--surface); border-color: #16a34a; box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.12); }
.btn-send { margin-top: 0.5rem; padding: 1rem; background: #16a34a; color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: background 0.2s; }
.btn-send:hover:not(:disabled) { background: #15803d; }
.btn-send:disabled { background: #cbd5e1; cursor: not-allowed; }
.feedback-alert { padding: 1rem; border-radius: 10px; font-size: 0.9rem; font-weight: 500; text-align: center; }
.feedback-alert.success { background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0; }
.feedback-alert.error { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
</style>