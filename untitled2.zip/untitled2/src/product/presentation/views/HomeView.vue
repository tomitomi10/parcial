<script setup>
import { ref, onMounted, reactive } from 'vue';
import { FakeProductApi } from '../../infrastructure/data-sources/FakeProductApi';
import ProductCard from '../components/ProductCard.vue';

const productRepository = new FakeProductApi();
const products = ref([]);
const loading = ref(true);

// --- ESTADOS PARA LA MODAL DE EDICIÓN ---
const isEditModalOpen = ref(false);
const editingPlotId = ref(null);
const editForm = reactive({
  name: '',
  location: '',
  hectares: 0
});

// --- ESTADOS PARA LA NUEVA MODAL DE DETALLES ---
const isDetailsModalOpen = ref(false);
const selectedPlot = ref(null);

const loadPlots = async () => {
  products.value = await productRepository.getAll();
  loading.value = false;
};

onMounted(() => {
  loadPlots();
});

// Lógica de Edición
const openEditModal = (plot) => {
  editingPlotId.value = plot.id;
  editForm.name = plot.name;
  editForm.location = plot.location;
  editForm.hectares = plot.hectares;
  isEditModalOpen.value = true;
};

const closeEditModal = () => {
  isEditModalOpen.value = false;
  editingPlotId.value = null;
};

const onUpdateSubmit = async () => {
  try {
    await productRepository.update(editingPlotId.value, {
      name: editForm.name,
      location: editForm.location,
      hectares: editForm.hectares
    });
    await loadPlots();
    closeEditModal();
  } catch (error) {
    alert(error.message);
  }
};

// --- LÓGICA PARA VER DETALLES ---
const openDetailsModal = (plot) => {
  selectedPlot.value = plot;
  isDetailsModalOpen.value = true;
};

const closeDetailsModal = () => {
  isDetailsModalOpen.value = false;
  selectedPlot.value = null;
};
</script>

<template>
  <div class="catalog-view">
    <header class="view-header">
      <h1>{{ $t('catalog.title') }}</h1>
      <p>{{ $t('catalog.subtitle') }}</p>
    </header>

    <div v-if="loading" class="loading-wrapper">
      <div class="spinner"></div>
      <p>{{ $t('catalog.loading') }}</p>
    </div>

    <div v-else class="grid-container">
      <div v-for="product in products" :key="product.id" class="card-wrapper">
        <ProductCard :item="product" @click="openDetailsModal(product)" style="cursor: pointer;" />
        <button class="btn-edit-trigger" @click="openEditModal(product)">
          ✏️ {{ $t('catalog.btnEditTrigger') }}
        </button>
      </div>
    </div>

    <div v-if="isEditModalOpen" class="modal-overlay" @click.self="closeEditModal">
      <div class="modal-card">
        <div class="modal-header">
          <h3>{{ $t('modal.title') }} (ID: {{ editingPlotId }})</h3>
          <button class="btn-close" @click="closeEditModal">&times;</button>
        </div>

        <form @submit.prevent="onUpdateSubmit" class="modal-form">
          <div class="form-group">
            <label>{{ $t('modal.labelName') }}</label>
            <input v-model="editForm.name" type="text" required />
          </div>

          <div class="form-group">
            <label>{{ $t('modal.labelLocation') }}</label>
            <input v-model="editForm.location" type="text" required />
          </div>

          <div class="form-group">
            <label>{{ $t('modal.labelHectares') }}</label>
            <input v-model="editForm.hectares" type="number" step="0.1" required />
          </div>

          <div class="modal-actions">
            <button type="button" class="btn-cancel" @click="closeEditModal">
              {{ $t('modal.btnCancel') }}
            </button>
            <button type="submit" class="btn-save-changes">
              {{ $t('modal.btnSave') }}
            </button>
          </div>
        </form>
      </div>
    </div>

    <div v-if="isDetailsModalOpen" class="modal-overlay" @click.self="closeDetailsModal">
      <div class="modal-card modal-details">
        <div class="modal-header">
          <h3>📋 {{ locale === 'en' ? 'Plot Technical Dossier' : 'Expediente Técnico de Parcela' }}</h3>
          <button class="btn-close" @click="closeDetailsModal">&times;</button>
        </div>

        <div class="details-content" v-if="selectedPlot">
          <img :src="selectedPlot.imageUrl" alt="Plot Graphic" class="details-img" />

          <div class="info-grid">
            <div class="info-item">
              <span class="info-label">ID Sistema</span>
              <span class="info-value">#{{ selectedPlot.id }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">Nombre del Cultivo</span>
              <span class="info-value">{{ selectedPlot.name }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">Ubicación Geográfica</span>
              <span class="info-value">📍 {{ selectedPlot.location }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">Área de Extensión</span>
              <span class="info-value">📐 {{ selectedPlot.hectares }} Hectáreas</span>
            </div>
            <div class="info-item">
              <span class="info-label">Fecha Alta Monitoreo</span>
              <span class="info-value">📅 {{ selectedPlot.monitoringStartDate }}</span>
            </div>
          </div>

          <div class="agro-metrics">
            <h4>📊 Indicadores en Tiempo Real (Simulación)</h4>
            <div class="metrics-flex">
              <div class="metric-pill">💧 Humedad: 74%</div>
              <div class="metric-pill">☀️ Radiación UV: Óptima</div>
              <div class="metric-pill">🌱 Salud de Tierra: A+</div>
            </div>
          </div>
        </div>

        <div class="modal-actions">
          <button type="button" class="btn-cancel" @click="closeDetailsModal">
            {{ $t('modal.btnCancel') ? 'Cerrar' : 'Close' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.view-header { text-align: center; margin-bottom: 3.5rem; }
.view-header h1 {
  font-size: 2.6rem; font-weight: 800; letter-spacing: -0.8px; margin-bottom: 0.8rem;
  background: linear-gradient(to right, #0f172a, #16a34a);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.view-header p { color: var(--text-muted); font-size: 1.05rem; max-width: 650px; margin: 0 auto; }
.grid-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(310px, 1fr)); gap: 2.5rem; }
.card-wrapper { display: flex; flex-direction: column; gap: 0.75rem; }

.btn-edit-trigger {
  width: 100%; padding: 0.6rem; background: #f1f5f9; color: #475569;
  border: 1px dashed #cbd5e1; border-radius: 10px; font-weight: 600;
  font-size: 0.85rem; cursor: pointer; transition: all 0.2s;
}
.btn-edit-trigger:hover { background: #e2e8f0; color: var(--text-main); border-color: #94a3b8; }

.loading-wrapper { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 6rem 0; gap: 1.2rem; color: var(--text-muted); }
.spinner { width: 38px; height: 38px; border: 4px solid var(--border); border-top-color: #16a34a; border-radius: 50%; animation: spin 0.8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ESTILOS DE LAS VENTANAS MODALES */
.modal-overlay {
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background: rgba(15, 23, 42, 0.4); backdrop-filter: blur(6px);
  display: flex; justify-content: center; align-items: center; z-index: 100;
}
.modal-card {
  background: var(--surface); width: 100%; max-width: 460px;
  padding: 2.2rem; border-radius: var(--radius); box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
  border: 1px solid var(--border); animation: scaleUp 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.modal-details { max-width: 550px; } /* Ancho expandido para detalles */

@keyframes scaleUp { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }

.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.8rem; }
.modal-header h3 { font-size: 1.3rem; font-weight: 800; color: var(--text-main); }
.btn-close { background: none; border: none; font-size: 1.6rem; color: var(--text-muted); cursor: pointer; }
.btn-close:hover { color: #ef4444; }

.modal-form { display: flex; flex-direction: column; gap: 1.2rem; }
.form-group { display: flex; flex-direction: column; gap: 0.4rem; }
.form-group label { font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }
.form-group input { padding: 0.8rem; border: 1px solid var(--border); background: #f8fafc; border-radius: 8px; font-size: 0.95rem; color: var(--text-main); outline: none; }

.modal-actions { display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem; }
.btn-cancel { padding: 0.7rem 1.2rem; background: #f1f5f9; border: none; border-radius: 8px; font-weight: 600; color: #475569; cursor: pointer; }
.btn-cancel:hover { background: #e2e8f0; }
.btn-save-changes { padding: 0.7rem 1.4rem; background: #16a34a; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; }
.btn-save-changes:hover { background: #15803d; }

/* DISEÑO INTERNO DEL DETALLE */
.details-content { display: flex; flex-direction: column; gap: 1.25rem; }
.details-img { width: 100%; height: 220px; object-fit: cover; border-radius: 12px; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; background: #f8fafc; padding: 1.25rem; border-radius: 12px; border: 1px solid var(--border); }
.info-item { display: flex; flex-direction: column; gap: 0.2rem; }
.info-item:nth-child(2) { grid-column: span 2; } /* Nombre completo expandido */
.info-label { font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }
.info-value { font-size: 0.95rem; font-weight: 600; color: var(--text-main); }
.agro-metrics { background: #f0fdf4; border: 1px solid #bbf7d0; padding: 1.2rem; border-radius: 12px; }
.agro-metrics h4 { font-size: 0.85rem; font-weight: 700; color: #166534; margin-bottom: 0.6rem; text-transform: uppercase; }
.metrics-flex { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.metric-pill { background: var(--surface); border: 1px solid #dcfce7; padding: 4px 10px; font-size: 0.8rem; font-weight: 600; color: #15803d; border-radius: 6px; }
</style>