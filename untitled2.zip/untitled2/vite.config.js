import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Asegúrate de que lleve el "export default" idéntico a este:
export default defineConfig({
    plugins: [vue()],
})